#include <Servo.h>
#include <math.h>

Servo coxaservo;
Servo femurservo;
Servo tibiaservo;

const float a = 60;   //femur
const float b = 107;  //tibia
const float l = 44;   //coxa offset

int x, y, z;

struct Main_Vec
{
  int x, y, z;
};

void setup() {
  Serial.begin(9600);

  coxaservo.attach(9);
  femurservo.attach(10);
  tibiaservo.attach(11);
}

void loop() {
  walk();
}

void IK(Main_Vec targets[], int n) {
  for (int i = 0; i < n; i++) {

    x=(targets[i].x);
    y=(targets[i].y);
    z=(targets[i].z);

    float r = sqrt(x * x + y * y);
    float d = r - l;
    float c = sqrt(z * z + d * d);
    //angles
    float theta1 = atan2(y, x) * 180.0 / PI;
    float theta2 = atan2(d, -z) * 180.0 / PI + acos((a * a + c * c - b * b) / (2 * a * c)) * 180.0 / PI;
    float theta3 = acos((a * a + b * b - c * c) / (2 * a * b)) * 180.0 / PI;
    //check values
    Serial.print("Theta1 (coxa): ");
    Serial.println(theta1);
    Serial.print("Theta2 (femur): ");
    Serial.println(theta2);
    Serial.print("Theta3 (tibia): ");
    Serial.println(theta3);
    //move servos
    coxaservo.write(constrain(theta1, 0, 180));
    femurservo.write(constrain(180 - theta2, 20, 180));
    tibiaservo.write(constrain(theta3, 50, 180));

    delay(100);
  }
}

void walk() {
  Main_Vec targets[] = {
    { 100, 120, -80 },
    { 50, 120, -55 },
    { 0, 120, 0 },
    { -50, 120, -55 },
    { -100, 120, -80 },
    { 0, 120, -80 }
  };
  IK(targets, 6);
}
