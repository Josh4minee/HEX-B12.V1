#include <FastLED.h>

CRGB leds1[5];
CRGB leds2[5];

int light;

void setup() {
  Serial.begin(9600);
  FastLED.addLeds<WS2812B, 5, GRB>(leds1, 5);
  FastLED.addLeds<WS2812B, 6, GRB>(leds2, 5);
  FastLED.setMaxPowerInVoltsAndMilliamps(5, 500);
  FastLED.setBrightness(60);
  FastLED.clear();
  FastLED.show();

  pinMode(4, OUTPUT);
  pinMode(7, OUTPUT);
  digitalWrite(4, HIGH);
  digitalWrite(7, HIGH);
}

void loop() {
  light = analogRead(A3);
  Serial.println(light);
  if (light < 15) {
    for (int i = 0; i < 5; i++) {
      leds1[i] = CRGB(255, 0, 0);
      leds2[i] = CRGB(255, 0, 0);
      FastLED.show();
    }
  }
  else {
    for (int i = 0; i < 5; i++) {
      leds1[i] = CRGB(0, 0, 0);
      leds2[i] = CRGB(0, 0, 0);
      FastLED.show();
    }
  }
}