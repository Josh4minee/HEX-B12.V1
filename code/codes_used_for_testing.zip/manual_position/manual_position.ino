#include <Servo.h>
Servo coxaservo;
Servo femurservo;
Servo tibiaservo;
void setup()
{
  coxaservo.attach(9);
  femurservo.attach(10);
  tibiaservo.attach(11);

  coxaservo.write(90);
  femurservo.write(90);
  tibiaservo.write(180);
}

void loop()
{
}
