#include <Servo.h>
#include <math.h>

Servo coxaservo;
Servo femurservo;
Servo tibiaservo;

const float a = 60; //femur
const float b = 103; //tibia
const float l = 43; //coxa offset

void setup()
{
  Serial.begin(9600);

  coxaservo.attach(9);
  femurservo.attach(10);
  tibiaservo.attach(11);

  coxaservo.write(90);
  femurservo.write(90);
  tibiaservo.write(90);

}

void loop()
{
  if (Serial.available())
  {
    float x = Serial.parseFloat(); //read
    float y = Serial.parseFloat(); //read
    float z = Serial.parseFloat(); //read
    delay(10);
    while (Serial.available()) Serial.read(); //buffer clear
    //numbers
    float r = sqrt(x*x + y*y);
    float d = r - l;
    float c = sqrt(z*z + d*d);
    //angles
    float theta1 = atan2(y, x) * 180.0 / PI;
    float theta2 = atan2(d, -z) * 180.0 / PI + acos((a * a + c * c - b * b) / (2 * a * c)) * 180.0 / PI;
    float theta3 = acos((a * a + b * b - c * c) / (2 * a * b)) * 180.0 / PI;
    //check values
    Serial.print("Theta1 (coxa): "); Serial.println(theta1);
    Serial.print("Theta2 (femur): "); Serial.println(theta2);
    Serial.print("Theta3 (tibia): "); Serial.println(theta3);
    //move servos
    coxaservo.write(constrain(theta1, 0, 180));
    femurservo.write(constrain(180 - theta2, 0, 180));
    tibiaservo.write(constrain(theta3, 0, 180));
  }
}
