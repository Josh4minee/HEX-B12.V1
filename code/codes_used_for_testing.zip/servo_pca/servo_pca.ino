

#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>
Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);
#define SERVOMIN  125
#define SERVOMAX  575


void setup() {
  Serial.begin(9600);
  pwm.begin();
  pwm.setPWMFreq(60);
  yield();
  pinMode(4, OUTPUT);
  pinMode(7, OUTPUT);
  digitalWrite(4, LOW);
  digitalWrite(7, LOW);
}

// the code inside loop() has been updated by Robojax
void loop() {

    pwm.setPWM(0, 0, 300 );
	delay(500);
    pwm.setPWM(0, 0, 255 );
	delay(500);
    pwm.setPWM(0, 0, 300 );
	delay(500);
    pwm.setPWM(0, 0, 255 );
	delay(500);
}